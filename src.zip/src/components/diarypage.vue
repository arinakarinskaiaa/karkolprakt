<!-- src/components/DiaryPage.vue -->
<script setup>
import { ref, computed } from "vue"
import { useProducts } from "../composables/useProducts"
import useUsers from "../composables/useUsers"

const { products } = useProducts()
const { currentUser, saveCurrentUser } = useUsers()

const selectedProduct = ref("")
const grams = ref("")

function addToDiary() {
    if (!selectedProduct.value || !grams.value) return
    currentUser.value.diary.push({
        id: Date.now(),
        productId: selectedProduct.value,
        grams: Number(grams.value),
        date: new Date().toISOString().slice(0, 10)
    })
    saveCurrentUser()
    grams.value = ""
}

const today = new Date().toISOString().slice(0, 10)
const todayList = computed(() => {
    return currentUser.value?.diary.filter(i => i.date === today) || []
})

const totalCalories = computed(() => {
    return todayList.value.reduce((sum, item) => {
        const product = products.value.find(p => p.id == item.productId)
        return sum + (product ? (product.calories * item.grams / 100) : 0)
    }, 0)
})
</script>

<template>
    <div class="diary-page">
        <h1>Дневник питания</h1>

        <div class="add-entry">
            <select v-model="selectedProduct">
                <option disabled value="">Выбери продукт</option>
                <option v-for="p in products" :key="p.id" :value="p.id">
                    {{ p.name }} ({{ p.calories }} ккал)
                </option>
            </select>
            <input v-model="grams" type="number" placeholder="Граммы" />
            <button @click="addToDiary">Добавить</button>
        </div>

        <div class="today-summary">
            <h2>Сегодня</h2>
            <div v-if="todayList.length === 0" class="empty">
                Ничего не съедено
            </div>
            <div v-for="item in todayList" :key="item.id" class="entry">
                {{
                    products.find(p => p.id == item.productId)?.name
                }} — {{ item.grams }} г
            </div>
            <h3>Итого: {{ Math.round(totalCalories) }} ккал</h3>
        </div>
    </div>
</template>

<style scoped>
.diary-page {
    max-width: 600px;
    margin: 40px auto;
    padding: 20px;
}

select,
input {
    padding: 8px;
    margin: 5px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button {
    padding: 8px 12px;
    background: #e60000;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.entry {
    padding: 6px 0;
}

.empty {
    color: #999;
    font-style: italic;
}
</style>