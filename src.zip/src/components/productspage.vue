<!-- src/components/ProductsPage.vue -->
<script setup>
import { ref } from "vue"
import { useProducts } from "../composables/useProducts"
import useUsers from "../composables/useUsers"

const { products, addProduct } = useProducts()
const { currentUser } = useUsers()

const form = ref({
    name: "",
    calories: ""
})

function doAdd() {
    if (!form.value.name || !form.value.calories) return
    addProduct(form.value.name, Number(form.value.calories))
    form.value.name = ""
    form.value.calories = ""
}
</script>

<template>
    <div class="products-page">
        <h1>Продукты</h1>

        <div class="add-product">
            <h3>Добавить свой продукт</h3>
            <input v-model="form.name" placeholder="Название" />
            <input v-model="form.calories" type="number" placeholder="Калории (на 100 г)" />
            <button @click="doAdd">Добавить</button>
        </div>

        <h3>Готовые продукты</h3>
        <ul class="product-list">
            <li v-for="p in products" :key="p.id">
                {{ p.name }} — {{ p.calories }} ккал / 100г
            </li>
        </ul>
    </div>
</template>

<style scoped>
.products-page {
    max-width: 600px;
    margin: 40px auto;
    padding: 20px;
}

input {
    padding: 8px;
    margin: 5px;
    width: 200px;
}

button {
    padding: 8px 12px;
    background: #e60000;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.product-list {
    list-style: none;
    margin-top: 20px;
}

.product-list li {
    padding: 8px;
    border-bottom: 1px solid #eee;
}
</style>