<script setup>
import { computed, ref } from "vue"
import { RouterLink } from "vue-router"
import { useRecipes } from "../composables/useRecipes"


const { recipes } = useRecipes()
console.log('Рецепты:', recipes.value)
const search = ref("")
const filter = ref("all")

const filteredRecipes = computed(() => {

    let result = recipes.value

    if (search.value) {
        result = result.filter(r =>
            r.title.toLowerCase().includes(search.value.toLowerCase())
        )
    }

    if (filter.value !== "all") {
        result = result.filter(r => r.difficulty === filter.value)
    }

    return result
})
</script>

<template>

    <h1 class="section-title">Рецепты</h1>

    <div class="controls">

        <input v-model="search" placeholder="Поиск рецепта..." class="search-input" />

        <div class="filters">

            <button @click="filter = 'all'" class="btn" :class="{ active: filter === 'all' }">
                Все
            </button>

            <button @click="filter = 'easy'" class="btn" :class="{ active: filter === 'easy' }">
                Лёгкие
            </button>

            <button @click="filter = 'medium'" class="btn" :class="{ active: filter === 'medium' }">
                Средние
            </button>

            <button @click="filter = 'hard'" class="btn" :class="{ active: filter === 'hard' }">
                Сложные
            </button>

        </div>
    </div>

    <section class="recipes">

        <RouterLink v-for="recipe in filteredRecipes" :key="recipe.id"
            :to="{ name: 'recipe', params: { id: recipe.id } }" class="recipe-card">
            <img :src="recipe.image" alt="Фото рецепта">
            <div class="content">

                <h3>{{ recipe.title }}</h3>

                <p>{{ recipe.description }}</p>

                <div class="info">
                    <span>{{ recipe.calories }} ккал</span>
                    <span>{{ recipe.time }} мин</span>
                </div>

            </div>

        </RouterLink>

    </section>

</template>

<style scoped>
.section-title {
    text-align: center;
    margin: 30px 0;
}

.controls {
    max-width: 1000px;
    margin: auto;
    margin-bottom: 30px;
}

.search-input {
    width: 100%;
    padding: 12px;
    margin-bottom: 15px;
}

.filters {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.btn {
    padding: 10px 15px;
    border: none;
    background: #e60000;
    color: white;
    cursor: pointer;
}

.active {
    background: black;
}

.recipes {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
}

.recipe-card {
    width: 300px;
    border: 1px solid #ddd;
    border-radius: 12px;
    overflow: hidden;
    text-decoration: none;
    color: black;
    transition: 0.3s;
    background: white;
}

.recipe-card:hover {
    transform: translateY(-5px);
}

.recipe-card img {
    width: 100%;
    height: 220px;
    object-fit: cover;
}

.content {
    padding: 15px;
}

.info {
    display: flex;
    justify-content: space-between;
    margin-top: 10px;
}
</style>
