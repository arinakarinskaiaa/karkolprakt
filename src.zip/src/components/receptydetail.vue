<script setup>
import { computed } from "vue"
import { useRoute } from "vue-router"
import { useRecipes } from "../composables/useRecipes"

const route = useRoute()

const { getById } = useRecipes()

const recipe = computed(() => {
    return getById(route.params.id)
})
</script>

<template>

    <div v-if="recipe" class="recipe-detail">

        <div class="image-block">
            <img :src="recipe.image" class="main-image" />
        </div>

        <div class="info-block">

            <h1>{{ recipe.title }}</h1>

            <div class="stats">
                <span>{{ recipe.calories }} ккал</span>
                <span>{{ recipe.time }} минут</span>
            </div>

            <div class="tabs">
                <RouterLink :to="{ name: 'recepty.description', params: { id: recipe.id } }" class="tab">
                    Описание
                </RouterLink>

                <RouterLink :to="{ name: 'recepty.ingredients', params: { id: recipe.id } }" class="tab">
                    Ингредиенты
                </RouterLink>

                <RouterLink :to="{ name: 'recepty.steps', params: { id: recipe.id } }" class="tab">
                    Приготовление
                </RouterLink>

            </div>

            <div class="content">
                <RouterView />
            </div>

        </div>

    </div>

</template>

<style scoped>
.recipe-detail {
    max-width: 1200px;
    margin: auto;
    display: flex;
    gap: 40px;
    padding: 40px 20px;
}

.image-block {
    flex: 1;
}

.main-image {
    width: 100%;
    border-radius: 15px;
}

.info-block {
    flex: 1;
}

.stats {
    display: flex;
    gap: 20px;
    margin: 15px 0;
}

.tabs {
    display: flex;
    gap: 10px;
    margin: 20px 0;
}

.tab {
    padding: 10px 15px;
    background: #f2f2f2;
    text-decoration: none;
    color: black;
    border-radius: 8px;
}

.router-link-active {
    background: #e60000;
    color: white;
}

.content {
    padding: 20px;
    background: #fafafa;
    border-radius: 12px;
}
</style>
