<script setup>
import { ref } from "vue"
import useUsers from "../composables/useUsers"
import { useRouter } from "vue-router"

const { login: loginUser } = useUsers()
const router = useRouter()

const form = ref({
    login: "",
    password: ""
})

const error = ref("")

function doLogin() {
    error.value = ""
    if (!form.value.login || !form.value.password) {
        error.value = "Заполните все поля"
        return
    }
    if (loginUser(form.value.login, form.value.password)) {
        router.push({ name: "diary" })
    } else {
        error.value = "Неверный логин или пароль"
    }
}
</script>

<template>
    <div class="auth-form">
        <h2>Вход</h2>
        <form @submit.prevent="doLogin">
            <input v-model="form.login" placeholder="Логин" />
            <input v-model="form.password" type="password" placeholder="Пароль" />
            <button type="submit">Войти</button>
        </form>
        <p v-if="error" class="error">{{ error }}</p>
        <RouterLink to="/registracia">Нет аккаунта? Зарегистрироваться</RouterLink>
    </div>
</template>

<style scoped>
.auth-form {
    max-width: 400px;
    margin: 40px auto;
    padding: 20px;
    text-align: center;
}

input {
    width: 100%;
    padding: 10px;
    margin: 8px 0;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button {
    padding: 10px 20px;
    background: #e60000;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

button:hover {
    background: #cc0000;
}

.error {
    color: red;
    font-size: 14px;
    margin-top: 10px;
}
</style>