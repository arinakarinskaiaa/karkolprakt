import { createRouter, createWebHistory } from "vue-router"
import login from "./components/login.vue"
import registracia from "./components/registracia.vue"
import diary from "./components/diarypage.vue"
import productspage from "./components/productspage.vue"
const routes = [
    { path: "/login", component: login },
    { path: "/registracia", component: registracia },
    { path: "/diary", component: diary },
    { path: "/products", component: productspage }
]
export default createRouter({
    history: createWebHistory(),
    routes
})