import { createApp } from 'vue'
import './style.css'
import App from './App.vue'
import router from './route.js'  // ← импортируем роутер

const app = createApp(App)

app.use(router)  // ← подключаем роутер

app.mount('#app')
