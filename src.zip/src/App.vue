<script setup>

</script>

<script setup>
import { RouterLink, RouterView } from 'vue-router'
import { useRouter } from 'vue-router'
import useUsers from './composables/useUsers'

const router = useRouter()
const { currentUser, logout } = useUsers()

function doLogout() {
  logout()
  router.push({ name: 'login' })
}
</script>

<template>
  <header class="header">
    <RouterLink :to="{ name: 'diary' }" class="logo-link">
      <div class="logo">Food<span>Diary</span></div>
    </RouterLink>

    <nav class="nav">
      <RouterLink :to="{ name: 'diary' }">Дневник</RouterLink>
      <RouterLink :to="{ name: 'products' }">Продукты</RouterLink>
    </nav>

    <div class="auth-controls">
      <div v-if="currentUser" class="user-info">
        Привет, <b>{{ currentUser.login }}</b>
        <button @click="doLogout" class="btn-logout">Выйти</button>
      </div>
      <div v-else>
        <RouterLink :to="{ name: 'login' }" class="btn-auth">Войти</RouterLink>
        <RouterLink :to="{ name: 'registracia' }" class="btn-auth">Регистрация</RouterLink>
      </div>
    </div>
  </header>

  <main class="main-content">
    <RouterView />
  </main>

  <footer class="footer">
    <p>© 2025 FoodDiary. Твой путь к осознанному питанию.</p>
  </footer>
</template>

<style scoped>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #000;
  padding: 15px 40px;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  width: 100%;
  height: 60px;
  color: #fff;
  z-index: 1000;
}

.logo-link {
  text-decoration: none;
  display: flex;
  align-items: center;
  height: 100%;
}

.logo {
  font-size: 26px;
  font-weight: bold;
  height: 100%;
  display: flex;
  align-items: center;
  color: #fff;
}

.logo span {
  color: #e60000;
}

.nav a {
  color: #fff;
  text-decoration: none;
  padding: 0 18px;
  font-size: 16px;
}

.nav a:hover {
  color: #e60000;
}

.auth-controls {
  display: flex;
  align-items: center;
  gap: 10px;
}

.user-info {
  font-size: 14px;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 10px;
}

.btn-auth {
  padding: 6px 12px;
  background: #e60000;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
  text-decoration: none;
}

.btn-auth:hover {
  background: #cc0000;
}

.btn-logout {
  padding: 6px 12px;
  background: #999;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
}

.main-content {
  margin-top: 60px;
  min-height: calc(100vh - 60px - 60px);
  padding: 20px 0;
  background: #f9f9f9;
}

.footer {
  text-align: center;
  padding: 15px 0;
  background: #000;
  color: #fff;
  width: 100%;
  position: relative;
  margin-top: 40px;
}
</style>
